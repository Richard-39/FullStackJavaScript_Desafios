module.exports = {
    KEY: 'misecretkey',
}