var page = 1;

$(document).ready(async (element)=>{

    const token = localStorage.getItem('jwt-key');
    if (token) {

        $('form').hide();
        $('.hideable').show();

        const data = await getPost(token);

        addPhotosToFeed(data);


        
    } else {
        $('form').show();
        $('.hideable').hide();

        $('#feed').html("");

    }
});


$('form').submit(async (element)=>{
    element.preventDefault();

    let emailUser = $('input[type=email]').val();
    let passwordUser = $('input[type=password]').val();

    const JWT = await postData(emailUser, passwordUser);
    console.log(JWT);

    localStorage.setItem('jwt-key', JWT);
    location.reload();

});

const postData = async (email, password)=> {
    try {
        const response = await fetch('http://localhost:3000/api/login', 
        {
            method:'POST',
            body: JSON.stringify({email:email, password:password})
        });
        const {token} = await response.json();
        return token;

    } catch (err) {
        console.log("error: " + err);
    }
}

const getPost = async(jwt, page)=>{
    try {
        const response = await fetch(`http://localhost:3000/api/photos?page=${page}`, 
        {                    
            method:'GET',
            headers: {
                Authorization: `Bearer ${jwt}`,
                credentials: 'include'
            }
        });
        const {data} = await response.json();
        return data;

    } catch (error) {
        console.log("Error: " + error)
    }
}

const addPhotosToFeed = (array)=>{
    array.forEach(element => {
        $(`
            <div class="card my-3 mx-auto" style="width: 30rem;">
                <img src="${element.download_url}" class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Autor: ${element.author}</p>
                </div>
            </div>
        `).appendTo('#feed')
    });
}


const cerrarSesion = ()=>{
    localStorage.removeItem('jwt-key');
    location.reload(); 
}

const verMas = async () => {

    const token = localStorage.getItem('jwt-key');

    if (token){
        page++;
        const data = await getPost(token, page);
        addPhotosToFeed(data);


    } else {
        location.reload();
    } 
}