var myModal = new bootstrap.Modal(document.getElementById('spinerModal'));

$(document).ready(async ()=>{
    const jwt = localStorage.getItem('jwt');

    if (jwt){

        $('#iniciarSesionButton').hide();
        $('#situacionChileButton').show();
        $('#cerrarSesionButton').show();

        myModal.show();

        Promise.all([getData(jwt, "confirmed"), getData(jwt, "deaths"), getData(jwt, "recovered")])
        .then(
            (result)=>{

                if (result[0] && result[1] && result[2]){
                    callToChart(result[0], result[1], result[2]);
                }

                myModal.hide()

            }
            
        )
        .catch((error) => {
            console.log("Error: " + error);
        });

    } else {
        window.location.href = "http://localhost:3000/covid19";
    }
});

const getData = async(jwt, type)=> {
    try {
        const response = await fetch(`http://localhost:3000/api/${type}`, {
            method:'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        });

        const {data} = await response.json();
        return data;

    } catch (error) {
        console.log("Error: getData - " + type + " - "+ error);
        alert("Hubo un error en la consulta. Intentelo nuevamente.");
    }
}

var SingOut = () => {
    localStorage.removeItem('jwt');
    alert("Sesión cerrada, volviendo al inicio.");
    setTimeout(()=>{
        window.location.href = "http://localhost:3000/covid19";
    }, 3000);
}


var myChart;

function callToChart(confirmados, muertos, recuperados) {

    const labels = confirmados.map((element)=>{
        return element.date;
    });

    const data = {
        labels: labels,
        datasets: [
        {
          label: 'Confirmados',
          data: confirmados.map((element)=>{
              return element.total;
          }),
          fill: false,
          backgroundColor: ['rgba(255, 99, 132, 0.2)'],
          borderColor: ['rgb(255, 99, 132)'],
          tension: 0.1
        },
        {
        label: 'Muertos',
        data: muertos.map((element)=>{
            return element.total;
        }),
        fill: false,
        backgroundColor: ['rgba(100, 100, 100, 0.2)'],
        borderColor: ['rgb(0,0,0)'],
        tension: 0.1
        },
        {
        label: 'Recuperados',
        data: recuperados.map((element)=>{
            return element.total;
        }),
        fill: false,
        backgroundColor: ['rgba(75, 192, 192, 0.2)'],
        borderColor: ['rgb(75, 192, 192)'],
        tension: 0.1
        }
        ]
    };

    const config = {
        type: 'line',
        data: data,
      };

    myChart = new Chart(
        document.getElementById('myChart'),
        config
    );
}



